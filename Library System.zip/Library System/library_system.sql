-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 12, 2024 at 03:43 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `borrow_list`
--

CREATE TABLE `borrow_list` (
  `borrow_num` int(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `acct_no` int(255) NOT NULL,
  `book_num` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `item_list`
--

CREATE TABLE `item_list` (
  `item_no` int(11) NOT NULL,
  `book_name` varchar(255) NOT NULL,
  `book_author` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item_list`
--

INSERT INTO `item_list` (`item_no`, `book_name`, `book_author`, `status`) VALUES
(1, 'To Kill a Mocking', 'Harper Lee', 'Available'),
(2, '1984', 'George Orwell', 'Available'),
(3, 'The Great Gatsby', 'F. Scott Fitzgerald', 'Available'),
(4, 'Pride and Prejudice', 'Jane Austen', 'Available'),
(5, 'The Catcher in the Rye', 'J.D. Salinger', 'Available'),
(6, 'Harry Potter and the Sorcerer\'s Stone', 'J.K. Rowling', 'Available'),
(7, 'The Hobbit', 'J.R.R. Tolkien', 'Available'),
(8, 'The Lord of the Rings', 'J.R.R. Tolkien', 'Available'),
(9, 'The Da Vinci Code', 'Dan Brown', 'Available'),
(10, 'The Hunger Games', 'Suzanne Collins', 'Available'),
(11, 'The Girl with the Dragon Tattoo', 'Stieg Larsson', 'Available'),
(12, 'Gone Girl', 'Gillian Flynn', 'Available'),
(13, 'The Help', 'Kathryn Stockett', 'Available'),
(14, 'The Alchemist', 'Paulo Coelho', 'Available'),
(15, 'The Kite Runner', 'Khaled Hosseini', 'Available'),
(16, 'The Road', 'Cormac McCarthy', 'Available'),
(17, 'The Fault in Our Stars', 'John Green', 'Available'),
(18, 'The Book Thief', 'Markus Zusak', 'Available'),
(19, 'A Game of Thrones', 'George R.R. Martin', 'Available'),
(20, 'The Shining', 'Stephen King', 'Available'),
(21, 'The Chronicles of Narnia', 'C.S. Lewis', 'Available'),
(22, 'Lord of the Flies', 'William Golding', 'Available'),
(23, 'The Picture of Dorian Gray', 'Oscar Wilde', 'Available'),
(24, 'Brave New World', 'Aldous Huxley', 'Available'),
(25, 'The Grapes of Wrath', 'John Steinbeck', 'Available'),
(26, 'Alice\'s Adventures in Wonderland', 'Lewis Carroll', 'Available'),
(27, 'Moby-Dick', 'Herman Melville', 'Available'),
(28, 'Frankenstein', 'Mary Shelley', 'Available'),
(29, 'Jane Eyre', 'Charlotte Bronte', 'Available'),
(30, 'Wuthering Heights', 'Emily Bronte', 'Available'),
(31, 'Don Quixote', 'Miguel de Cervantes', 'Available'),
(32, 'One Hundred Years of Solitude', 'Gabriel Garcia Marquez', 'Available'),
(33, 'War and Peace', 'Leo Tolstoy', 'Available'),
(34, 'Crime and Punishment', 'Fyodor Dostoevsky', 'Available'),
(35, 'The Brothers Karamazov', 'Fyodor Dostoevsky', 'Available'),
(36, 'The Picture of Dorian Gray', 'Oscar Wilde', 'Available'),
(37, 'Les Misérables', 'Victor Hugo', 'Available'),
(38, 'The Adventures of Huckleberry Finn', 'Mark Twain', 'Available'),
(39, 'Anna Karenina', 'Leo Tolstoy', 'Available'),
(40, 'The Odyssey', 'Homer', 'Available'),
(41, 'Siddhartha', 'Hermann Hesse', 'Available'),
(42, 'The Divine Comedy', 'Dante Alighieri', 'Available'),
(43, 'The Three Musketeers', 'Alexandre Dumas', 'Available'),
(44, 'Dracula', 'Bram Stoker', 'Available'),
(45, 'Gulliver\'s Travels', 'Jonathan Swift', 'Available'),
(46, 'A Tale of Two Cities', 'Charles Dickens', 'Available'),
(47, 'The Scarlet Letter', 'Nathaniel Hawthorne', 'Available'),
(48, 'Fifty Shades of Grey', 'E.L. James', 'Available'),
(49, 'Fifty Shades Darker', 'E.L. James', 'Available'),
(50, 'Fifty Shades Freed', 'E.L. James', 'Available'),
(51, 'Airframe', 'Michael Crichton', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `acct_no` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `borrow_list`
--
ALTER TABLE `borrow_list`
  ADD PRIMARY KEY (`borrow_num`);

--
-- Indexes for table `item_list`
--
ALTER TABLE `item_list`
  ADD PRIMARY KEY (`item_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`acct_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `borrow_list`
--
ALTER TABLE `borrow_list`
  MODIFY `borrow_num` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `item_list`
--
ALTER TABLE `item_list`
  MODIFY `item_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `acct_no` int(255) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
