﻿using System;
using System.IO;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Library_System
{
    public partial class AddItem : UserControl
    {
        //public LenderMainForm lender{ get; set;}
        public AddItem()//LenderMainForm _form1)
        {
            //lender = _form1;
            InitializeComponent();
            LogIn.Initialize();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LogIn.Insert("insert into item_list (book_name,book_author,status) values ('"+book_title.Text+"','"+book_author.Text+"','Available');");
            MessageBox.Show("Book successfully added to database.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            book_title.Text = null;
            book_author.Text = null;
        }
    }
}
