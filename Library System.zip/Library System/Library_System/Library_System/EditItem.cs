﻿using System;
using System.Windows.Forms;

namespace Library_System
{
    public partial class Edit_Item : UserControl
    {
        public Edit_Item()
        {
            InitializeComponent();
            LogIn.Initialize();
        }
        public int item_number;

        private string item_req()
        {
            string query = "book_name ='";
            query = query + book_name.Text;
            query = query + "', book_author ='" + book_author.Text;
            return query;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LogIn.Insert("update item_list set " + item_req() + "' where item_no = " + item_number + ";");
            MessageBox.Show("Changes successfully saved.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            book_name.Text = null;
            book_author.Text = null;
        }
    }
}
