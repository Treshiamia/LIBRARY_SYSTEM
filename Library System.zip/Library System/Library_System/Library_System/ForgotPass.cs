﻿using System;
using System.Windows.Forms;

namespace Library_System
{
    public partial class ForgotPass : Form
    {
        public ForgotPass()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Form login = new LogIn();
                login.Show();
                Close();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case 0x84:
                    base.WndProc(ref m);
                    if ((int)m.Result == 0x1)
                        m.Result = (IntPtr)0x2;
                    return;
            }

            base.WndProc(ref m);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == textBox3.Text)
            {
                LogIn.Insert("update users set password = '" +textBox2.Text + "' where username = " + LogIn.username + ";");
                MessageBox.Show("Change Password Success","Information",MessageBoxButtons.OK);
                LogIn login = new LogIn();
                login.Show();
                Hide();
            }
            else
            {
                MessageBox.Show("Passwords do not match", "Error", MessageBoxButtons.OK);
                textBox2.Text = null;
                textBox3.Text = null;
            }
        }
    }
}
