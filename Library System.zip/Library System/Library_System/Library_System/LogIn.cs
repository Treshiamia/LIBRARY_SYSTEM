﻿using System;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace Library_System
{
    public partial class LogIn : Form
    {
        public static string username, reg_username, password, reg_password, acct_no;
        public bool noUser = true, compUser, correctpass;
        public static MySqlConnection conn;
        public static string mcs;

        public LogIn()
        {
            InitializeComponent();
            Initialize();
        }

        public static void Initialize()
        {
            mcs = "server=localhost;uid=root;pwd=;database=library_system;sslmode=none;";
            conn = new MySqlConnection(mcs);
        }

        public static bool OpenConnection()
        {
            try
            {
                conn.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public static bool CloseConnection()
        {
            try
            {
                conn.Dispose();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public static void Insert(string q)
        {
            if (OpenConnection())
            {
                try
                {
                    MySqlCommand cmd = new MySqlCommand(q, conn);
                    cmd.ExecuteNonQuery();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    CloseConnection();
                }
            }
        }
        public void comparePass(string myqueryAd)
        {
            string pass;
            compUser = false;
            if (OpenConnection())
            {
                try
                {
                    MySqlCommand command = new MySqlCommand(myqueryAd, conn);
                    MySqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        pass = reader[0].ToString();
                        if (pass == password)
                        {
                            acct_no = reader[1].ToString();
                            compUser = true;
                            noUser = false;
                        }
                        else if (pass == "")
                        {
                            noUser = true;
                        }
                    }


                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    CloseConnection();
                }
            }
        }

        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case 0x84:
                    base.WndProc(ref m);
                    if ((int)m.Result == 0x1)
                        m.Result = (IntPtr)0x2;
                    return;
            }
            base.WndProc(ref m);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if ((usertxt.Text == "") && (passtxt.Text == ""))
            {
                Form register = new Register();
                register.Show();
                Hide();
            }
            else
            {
                if (MessageBox.Show("Do you really want to register?", "Exit", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    Form register = new Register();
                    register.Show();
                    Hide();
                }
            }

        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Application.ExitThread();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void button3_MouseDown(object sender, MouseEventArgs e)
        {
            passtxt.PasswordChar = '\0';
        }

        private void button3_MouseUp(object sender, MouseEventArgs e)
        {
            passtxt.PasswordChar = '●';
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string checkQueryuser = "SELECT password,acct_no FROM users where username = '" + usertxt.Text + "'";

            password = passtxt.Text;
            if ((usertxt.Text == "") || (passtxt.Text == ""))
            {
                MessageBox.Show("Please complete the following details", "Log - In");
                usertxt.Text = "";
                passtxt.Text = "";
            }
            else if ((usertxt.Text == "admin") && (passtxt.Text == "admin"))
            {
                Form lender = new LenderMainForm();
                lender.Show();
                Hide();
            }
            else
            {
                comparePass(checkQueryuser);
                if (!noUser)
                {
                    if (compUser)
                    {
                        Form borrow = new BorrowerMainForm();
                        borrow.Show();
                        Hide();
                    }
                    else
                    {
                        if (MessageBox.Show("Incorrect Password. Forgot Password?", "User Found", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            Form forgot = new ForgotPass();
                            forgot.Show();
                            Hide();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("User not Found", "Log - In");
                }
            }
            if ((usertxt.Text != "") && (passtxt.Text != ""))
            {
                usertxt.Text = "";
                passtxt.Text = "";
            }
        }
    }
}
