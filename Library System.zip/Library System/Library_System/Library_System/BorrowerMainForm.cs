﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Library_System
{
    public partial class BorrowerMainForm : Form
    {
        
        public BorrowerMainForm()
        {
            InitializeComponent();
            

        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Form login = new LogIn();
                login.Show();
                Close();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }


        private void BorrowerMainForm_Load(object sender, EventArgs e)
        {
            borrower_Control1.Enabled = true;
        }
        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case 0x84:
                    base.WndProc(ref m);
                    if ((int)m.Result == 0x1)
                        m.Result = (IntPtr)0x2;
                    return;
            }

            base.WndProc(ref m);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            borrower_Control1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            borrower_Control1.Enabled = true;
        }

        private void borrower_Control1_Click(object sender, EventArgs e)
        {
        }

        private void borrower_Control1_VisibleChanged(object sender, EventArgs e)
        {
            if(borrower_Control1.Visible==false)
            {
                Hide();
            }
        }
    }
}
