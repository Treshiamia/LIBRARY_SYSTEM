﻿using System;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace Library_System
{

    public partial class Register : Form
    {
        string reg_username, reg_password;
        public void Initialize()
        {
            LogIn.mcs = "server=localhost;uid=root;pwd=;database=library_system;";
            LogIn.conn = new MySqlConnection(LogIn.mcs);
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Form login = new LogIn();
                login.Show();
                Close();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void registerbtn_Click(object sender, EventArgs e)
        {
            if ((string.IsNullOrEmpty(usertxt.Text)) || (string.IsNullOrEmpty(passtxt.Text)) || (string.IsNullOrEmpty(conpasstxt.Text)))
            {
                MessageBox.Show("Kindly complete the information required.", "Incomplete", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                if (MessageBox.Show("Confirm Registration?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if ((passtxt.Text.Length >= 8) && (conpasstxt.Text.Length >= 8))
                    {
                        if (passtxt.Text == conpasstxt.Text)
                        {
                            reg_username = usertxt.Text;
                            reg_password = passtxt.Text;

                            string query = "INSERT INTO users (username, password) VALUES ('" + reg_username + "', '" + reg_password + "')";
                            if (LogIn.OpenConnection())
                            {
                                try
                                {
                                    MySqlCommand cmd = new MySqlCommand(query, LogIn.conn);
                                    cmd.ExecuteNonQuery();
                                    MessageBox.Show("You're Registered!", "Registration Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    Form login = new LogIn();
                                    login.Show();
                                    Hide();
                                    usertxt.Text = null;
                                    passtxt.Text = null;
                                }
                                catch (MySqlException ex)
                                {
                                    MessageBox.Show(ex.Message);
                                }
                                finally
                                {
                                    LogIn.CloseConnection();
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Passwords didn't Match", "Password Unmatched", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            conpasstxt.Text = null;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Password Length must be at least 8 characters.", "Password Length Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                else
                {
                }
            }
        }


        public static bool OpenConnection()
        {
            try
            {
                LogIn.conn.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public static bool CloseConnection()
        {
            try
            {
                LogIn.conn.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void Pbutton_MouseDown(object sender, MouseEventArgs e)
        {
            passtxt.PasswordChar = '\0';
        }

        private void Pbutton_MouseUp(object sender, MouseEventArgs e)
        {
            passtxt.PasswordChar = '●';
        }

        private void CPbutton_MouseDown(object sender, MouseEventArgs e)
        {
            conpasstxt.PasswordChar = '\0';
        }

        private void CPbutton_MouseUp(object sender, MouseEventArgs e)
        {
            conpasstxt.PasswordChar = '●';
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you really want to quit registraion?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Form Login = new LogIn();
                Login.Show();
                this.Hide();
            }
        }

        public Register()
        {
            InitializeComponent();
        }
        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case 0x84:
                    base.WndProc(ref m);
                    if ((int)m.Result == 0x1)
                        m.Result = (IntPtr)0x2;
                    return;
            }

            base.WndProc(ref m);
        }
    }
}
