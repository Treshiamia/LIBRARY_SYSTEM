﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Library_System
{
    public partial class Borrower_AddItem : Form
    {
        private List<ListViewItem> originalItems = new List<ListViewItem>();
        public Borrower_Control lender { get; set; }
        public Borrower_AddItem(Borrower_Control _form1)
        {
            lender = _form1;
            InitializeComponent();
            LogIn.Initialize();
        }

        public void Populate_ListView(string myquery)
        {
            listView1.Items.Clear();
            ListViewItem iItem;
            string query = myquery;
            if (LogIn.OpenConnection())
            {
                try
                {
                    MySqlCommand cmd = new MySqlCommand(query, LogIn.conn);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    while (dataReader.Read())
                    {
                        if(dataReader[3].ToString()=="Borrowed")
                        {
                            iItem = new ListViewItem(dataReader[0].ToString());
                            iItem.SubItems.Add(dataReader[1].ToString());
                            iItem.SubItems.Add(dataReader[2].ToString());
                            iItem.SubItems.Add(dataReader[3].ToString());
                            iItem.ForeColor = SystemColors.GrayText;
                            listView1.Items.Add(iItem);
                        }
                        else
                        {
                            iItem = new ListViewItem(dataReader[0].ToString());
                            iItem.SubItems.Add(dataReader[1].ToString());
                            iItem.SubItems.Add(dataReader[2].ToString());
                            iItem.SubItems.Add(dataReader[3].ToString());
                            iItem.ForeColor = SystemColors.ControlText;
                            listView1.Items.Add(iItem);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    LogIn.CloseConnection();
                }
                listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
                listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            }
        }

        private void Borrower_AddItem_Load(object sender, EventArgs e)
        {
            Populate_ListView("select item_no, book_name, book_author, status from item_list");
            foreach (ListViewItem item in listView1.Items)
            {
                originalItems.Add(item);
            }
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                string search = item.SubItems[1].Text;
                ListViewItem itm = lender.listView1.FindItemWithText(search);
                if (itm != null)
                {
                    MessageBox.Show("You have already selected this book.","Notification",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
                else
                {
                    ListViewItem iItem;
                    iItem = new ListViewItem(item.SubItems[0].Text);
                    iItem.SubItems.Add(item.SubItems[1].Text);
                    iItem.SubItems.Add(item.SubItems[2].Text);
                    lender.listView1.Items.Add(iItem);
                    lender.listView1.Refresh();
                    lender.listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
                    lender.listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
                }
                Hide();
            }

        }

        private void textBox1_KeyUp_1(object sender, KeyEventArgs e)
        {
            string searchText = textBox1.Text.ToLower();
            listView1.Items.Clear();

            foreach (ListViewItem item in originalItems)
            {
                bool found = false;
                foreach (ListViewItem.ListViewSubItem subItem in item.SubItems)
                {
                    if (subItem.Text.ToLower().Contains(searchText))
                    {
                        found = true;
                        break;
                    }
                }
                if (found)
                {
                    listView1.Items.Add(item);
                }
            }

            if (searchText=="")
            {
                listView1.Items.Clear();
                foreach (ListViewItem item in originalItems)
                {
                    listView1.Items.Add(item);
                }
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                if (item.ForeColor == SystemColors.GrayText)
                {
                    item.Selected = false;
                }
            }
        }
    }
}

