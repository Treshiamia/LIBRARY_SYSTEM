﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace Library_System
{
    public partial class Borrower_Control : UserControl
    {
        public Borrower_Control()
        {
            InitializeComponent();
            LogIn.Initialize();
        }

        public string date, book_list, stud_no, status;
        public int queue_no;

        private void button5_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            button5.Enabled = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listView1.Items.Count == 1)
            {
                foreach (ListViewItem item in listView1.SelectedItems)
                {
                    listView1.Items.Remove(item);
                }
                button4.Enabled = false;
                button5.Enabled = false;
            }
            else
            {
                foreach (ListViewItem item in listView1.SelectedItems)
                {
                    listView1.Items.Remove(item);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form borrow_additem = new Borrower_AddItem(this);
            borrow_additem.Show();
            button4.Enabled = true;
            button5.Enabled = true;
        }

        private void Borrower_Control_Load(object sender, EventArgs e)
        {
            button4.Enabled = false;
            button5.Enabled = false;
        }

        private string PopulateBook_List()
        {

            foreach (ListViewItem item in listView1.Items)
            {
                if (item.SubItems.Count > 0)
                {
                    string columnValue = item.SubItems[0].Text;
                    book_list += columnValue + ",";
                }
            }
            return book_list;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("Confirm to Borrow these books??", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {
                LogIn.Insert("insert into borrow_list (date, acct_no, book_num, status) values ('" + dateTimePicker1.Value.ToShortDateString() + "'," + LogIn.acct_no + ",'" + PopulateBook_List() + "','" + "Borrowed" + "');");

                foreach (ListViewItem item in listView1.Items)
                {
                    status = "Borrowed";
                    LogIn.Insert("update item_list set status = '" + status.ToString() + "' where item_no = " + item.SubItems[0].Text + ";");
                }
                dateTimePicker1.Value = DateTime.Now;
                listView1.Items.Clear();
                if (MessageBox.Show("Borrow Success! Returning to Login Screen.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    Form login = new LogIn();
                    login.Show();
                    Hide();
                }
            }
            else
            {

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to cancel this session?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Form login = new LogIn();
                login.Show();
                Hide();
            }
        }
    }
}
