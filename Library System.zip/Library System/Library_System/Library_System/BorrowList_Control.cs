﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Library_System
{
    public partial class BorrowList_Control : UserControl
    {
        public BorrowList_Control()
        {
            InitializeComponent();
        }

        string books;
        string[] books_split;

        public void Populate_ListView(string query)
        {
            listView1.Items.Clear();
            ListViewItem iItem;
            if (LogIn.OpenConnection())
            {
                try
                {
                    MySqlCommand cmd = new MySqlCommand(query, LogIn.conn);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    while (dataReader.Read())
                    {
                        iItem = new ListViewItem(dataReader[0].ToString());
                        iItem.SubItems.Add(dataReader[1].ToString());
                        iItem.SubItems.Add(dataReader[2].ToString());
                        listView1.Items.Add(iItem);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    LogIn.CloseConnection();
                }
                listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
                listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            }
        }

        public void Load_Items(int borrow_num)
        {
            listView2.Items.Clear();
            ListViewItem iItem;
            
            string query = "select book_num from borrow_list where borrow_num = "+borrow_num+";";
            if (LogIn.OpenConnection())
            {
                try
                {
                    MySqlCommand cmd = new MySqlCommand(query, LogIn.conn);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    while (dataReader.Read())
                    {
                        books = dataReader[0].ToString();
                    }
                    books_split = books.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    LogIn.CloseConnection();
                }
                listView2.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
                listView2.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            }
            foreach (string value in books_split)
            {
                query = "select item_no, book_name, book_author from item_list where item_no = " + value + ";";
                if (LogIn.OpenConnection())
                {
                    try
                    {
                        MySqlCommand cmd = new MySqlCommand(query, LogIn.conn);
                        MySqlDataReader dataReader = cmd.ExecuteReader();
                        while (dataReader.Read())
                        {
                            iItem = new ListViewItem(dataReader[0].ToString());
                            iItem.SubItems.Add(dataReader[1].ToString());
                            iItem.SubItems.Add(dataReader[2].ToString());
                            listView2.Items.Add(iItem);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        LogIn.CloseConnection();
                    }
                }
            }
            
        }

        private void queue_list_Load(object sender, EventArgs e)
        {
            Populate_ListView("SELECT borrow_list.borrow_num, users.username,borrow_list.status FROM borrow_list JOIN users ON borrow_list.acct_no = users.acct_no where borrow_list.status = 'Borrowed';");
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            foreach(ListViewItem item in listView1.SelectedItems)
            {
                Load_Items(Convert.ToInt32(item.SubItems[0].Text));
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Populate_ListView("SELECT borrow_list.borrow_num, users.username,borrow_list.status FROM borrow_list JOIN users ON borrow_list.acct_no = users.acct_no where borrow_list.status = 'Borrowed';");
            listView2.Items.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Populate_ListView("SELECT borrow_list.borrow_num, users.username,borrow_list.status FROM borrow_list JOIN users ON borrow_list.acct_no = users.acct_no;");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach(ListViewItem item2 in listView1.SelectedItems)
            {
                foreach (ListViewItem item in listView2.Items)
                {
                    LogIn.Insert("update item_list set status = 'Available' where item_no = " + item.SubItems[0].Text + ";");

                }
                LogIn.Insert("update borrow_list set status = 'Returned' where borrow_num = " + item2.SubItems[0].Text + ";");
            }
            Populate_ListView("SELECT borrow_list.borrow_num, users.username,borrow_list.status FROM borrow_list JOIN users ON borrow_list.acct_no = users.acct_no where borrow_list.status = 'Borrowed';");
            listView2.Items.Clear();
            MessageBox.Show("Return Successful.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
