﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Library_System
{
    public partial class LenderMainForm : Form
    {
        private List<ListViewItem> originalItems = new List<ListViewItem>();
        public AddItem additem;
        public LenderMainForm()
        {
            InitializeComponent();
            LogIn.Initialize();
        }
        int itemno;

        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case 0x84:
                    base.WndProc(ref m);
                    if ((int)m.Result == 0x1)
                        m.Result = (IntPtr)0x2;
                    return;
            }
            base.WndProc(ref m);
        }

        private void LenderMainForm_Load(object sender, EventArgs e)
        {
            Populate_ListView("select item_no,book_name,book_author,status from item_list");
            foreach (ListViewItem item in listView1.Items)
            {
                originalItems.Add(item);
            }
        }

        public void LoadBookInfo(int ID)
        {
            string query = "Select item_no, book_name, book_author from item_list where item_no = " + ID + "";
            if (LogIn.OpenConnection())
            {
                try
                {
                    MySqlCommand command = new MySqlCommand(query, LogIn.conn);
                    MySqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        edit_Item2.item_number = Convert.ToInt32(reader.GetString("item_no"));
                        edit_Item2.book_name.Text = reader.GetString("book_name");
                        edit_Item2.book_author.Text = reader.GetString("book_author");
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    LogIn.CloseConnection();
                }
            }
        }

        public void Populate_ListView(string myquery)
        {
            listView1.Items.Clear();
            ListViewItem iItem;
            string query = myquery;
            if (LogIn.OpenConnection())
            {
                try
                {
                    MySqlCommand cmd = new MySqlCommand(query, LogIn.conn);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    while (dataReader.Read())
                    {
                        iItem = new ListViewItem(dataReader[0].ToString());
                        iItem.SubItems.Add(dataReader[1].ToString());
                        iItem.SubItems.Add(dataReader[2].ToString());
                        iItem.SubItems.Add(dataReader[3].ToString());
                        listView1.Items.Add(iItem);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    LogIn.CloseConnection();
                }
                listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
                listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            addItem1.Visible = true;
            addItem1.book_author.Text = "";
            addItem1.book_title.Text = "";
            edit_Item2.Visible = false;
            queue_list1.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            edit_Item2.Visible = true;
            edit_Item2.button2.Enabled = true;
            edit_Item2.book_author.Enabled = true;
            edit_Item2.book_name.Enabled = true;
            addItem1.Visible = false;
            queue_list1.Visible = false;
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Form login = new LogIn();
                login.Show();
                Close();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                itemno = Convert.ToInt32(item.SubItems[0].Text);
                LoadBookInfo(itemno);
            }
            edit_Item2.Visible = true;
            addItem1.Visible = false;
            queue_list1.Visible = false;
            edit_Item2.button2.Enabled = false;
            edit_Item2.book_author.Enabled = false;
            edit_Item2.book_name.Enabled = false;
        }

        public void button4_Click(object sender, EventArgs e)
        {
            Populate_ListView("select item_no,book_name,book_author,status from item_list");
            edit_Item2.book_name.Text = "";
            edit_Item2.book_author.Text = "";
            edit_Item2.Visible = true;
            addItem1.Visible = false;
            queue_list1.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            queue_list1.Visible = true;
            queue_list1.Populate_ListView("SELECT borrow_list.borrow_num, users.username,borrow_list.status FROM borrow_list JOIN users ON borrow_list.acct_no = users.acct_no where borrow_list.status = 'Borrowed';");
            edit_Item2.Visible = false;
            addItem1.Visible = false;
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            string searchText = textBox1.Text.ToLower();
            listView1.Items.Clear();

            foreach (ListViewItem item in originalItems)
            {
                bool found = false;
                foreach (ListViewItem.ListViewSubItem subItem in item.SubItems)
                {
                    if (subItem.Text.ToLower().Contains(searchText))
                    {
                        found = true;
                        break;
                    }
                }
                if (found)
                {
                    listView1.Items.Add(item);
                }
            }

            if (searchText == "")
            {
                listView1.Items.Clear();
                foreach (ListViewItem item in originalItems)
                {
                    listView1.Items.Add(item);
                }
            }
        }
    }
}